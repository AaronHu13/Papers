package edu.neu.mhealth.debug.helper;

public class Global {

	public final static String APP_LOG_TAG = "mDebug"; 
}
